package com.example.groceryappb30.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.groceryappb30.R
import com.example.groceryappb30.adapters.AdapterCategory
import com.example.groceryappb30.models.Category
import com.example.groceryappb30.models.CategoryResponse
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var mList: ArrayList<Category> = ArrayList()
    lateinit var adapterCategory: AdapterCategory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        init()
    }

    private fun init() {
        getData()
        adapterCategory = AdapterCategory(this)
        recycler_view.adapter = adapterCategory
        recycler_view.layoutManager = GridLayoutManager(this, 2)
    }

    private fun getData() {
        var requestQueue = Volley.newRequestQueue(this)
        var request = StringRequest(
                Request.Method.GET,
                "http://grocery-second-app.herokuapp.com/api/category",
                Response.Listener {
                    var gson = Gson()
                    var categoryResponse = gson.fromJson(it, CategoryResponse::class.java)
                    adapterCategory.setData(categoryResponse.data)
                    progress_bar.visibility = View.GONE
                },
                Response.ErrorListener {
                    Toast.makeText(applicationContext, it.message, Toast.LENGTH_SHORT).show()
                    Log.d("abc", it.message.toString())
                }
        )
        requestQueue.add(request)
    }
}